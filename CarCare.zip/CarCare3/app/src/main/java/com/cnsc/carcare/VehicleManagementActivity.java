package com.cnsc.carcare;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class VehicleManagementActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;
    LinearLayout layoutVehicles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Ensure no swipe animation when entering
        overridePendingTransition(0, 0);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_management);

        db = new DatabaseHelper(this);
        session = new SessionManager(this);
        layoutVehicles = findViewById(R.id.layoutVehicles);

        // --- BACK BUTTON LOGIC ---
        // This matches the android:id="@+id/btnBack" from your XML
        ImageButton btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                finish(); // Closes this activity and returns to the previous one
            });
        }

        // Add Vehicle Button
        findViewById(R.id.btnAddVehicle).setOnClickListener(v -> {
            startActivity(new Intent(this, AddVehicleActivity.class));
            overridePendingTransition(0, 0);
        });

        // Initialize Navigation Click Listeners (Bottom Bar)
        setupNavigation();

        loadVehicles();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadVehicles();
    }

    private void setupNavigation() {
        // HOME
        findViewById(R.id.btnNavHome).setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        // HISTORY
        findViewById(R.id.btnNavHistory).setOnClickListener(v -> {
            startActivity(new Intent(this, HistoryActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        // REMINDERS
        findViewById(R.id.btnNavReminders).setOnClickListener(v -> {
            startActivity(new Intent(this, ReminderActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        // GARAGE (Already here - set as active)
        findViewById(R.id.btnNavVehicles).setOnClickListener(v -> {
            // Stay here
        });

        // FAB (Add Expense)
        findViewById(R.id.btnNavAddExpense).setOnClickListener(v -> {
            startActivity(new Intent(this, AddExpenseActivity.class));
            overridePendingTransition(0, 0);
        });
    }

    private void loadVehicles() {
        layoutVehicles.removeAllViews();
        int userId = session.getUserId();
        int activeId = session.getActiveVehicleId();
        Cursor cursor = db.getVehiclesByUser(userId);

        if (cursor == null || cursor.getCount() == 0) {
            TextView empty = new TextView(this);
            empty.setText("No vehicles yet. Tap + Add to get started!");
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, 60, 0, 0);
            layoutVehicles.addView(empty);
            return;
        }

        while (cursor.moveToNext()) {
            // Indices based on your DatabaseHelper column order
            final int id = cursor.getInt(0);
            final String name = cursor.getString(1); // Usually name is index 1 or 2
            String brand = cursor.getString(2);
            String model = cursor.getString(3);
            String year = cursor.getString(4);
            int odometer = cursor.getInt(5);
            boolean isActive = (id == activeId);

            CardView card = new CardView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 0, 24);
            card.setLayoutParams(params);
            card.setRadius(28f);
            card.setCardElevation(isActive ? 12f : 4f);

            LinearLayout inner = new LinearLayout(this);
            inner.setOrientation(LinearLayout.HORIZONTAL);
            inner.setPadding(40, 40, 40, 40);
            inner.setGravity(Gravity.CENTER_VERTICAL);

            if (isActive) {
                card.setCardBackgroundColor(getResources().getColor(android.R.color.white));
            }

            LinearLayout textGroup = new LinearLayout(this);
            textGroup.setOrientation(LinearLayout.VERTICAL);
            textGroup.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvName = new TextView(this);
            tvName.setText((isActive ? "✅ " : "🚗 ") + name);
            tvName.setTextSize(18f);
            tvName.setTextColor(getResources().getColor(R.color.blue_dark));
            tvName.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView tvInfo = new TextView(this);
            tvInfo.setText(brand + " " + model + " (" + year + ")\n" + odometer + " km");
            tvInfo.setTextSize(14f);
            tvInfo.setTextColor(android.graphics.Color.GRAY);

            textGroup.addView(tvName);
            textGroup.addView(tvInfo);

            LinearLayout btnGroup = new LinearLayout(this);
            btnGroup.setOrientation(LinearLayout.HORIZONTAL);
            btnGroup.setGravity(Gravity.CENTER_VERTICAL);

            // If not active, show the select button
            if (!isActive) {
                Button btnSelect = new Button(this);
                btnSelect.setText("Select");
                btnSelect.setAllCaps(false);
                btnSelect.setOnClickListener(v -> {
                    session.setActiveVehicle(id);
                    Toast.makeText(this, name + " set as active!", Toast.LENGTH_SHORT).show();
                    loadVehicles();
                });
                btnGroup.addView(btnSelect);
            }

            // Delete button
            ImageButton btnDelete = new ImageButton(this);
            btnDelete.setImageResource(android.R.drawable.ic_menu_delete);
            btnDelete.setBackground(null);
            btnDelete.setPadding(20, 0, 0, 0);
            btnDelete.setOnClickListener(v -> {
                db.deleteVehicle(id);
                if (isActive) session.setActiveVehicle(-1);
                Toast.makeText(this, "Vehicle removed", Toast.LENGTH_SHORT).show();
                loadVehicles();
            });
            btnGroup.addView(btnDelete);

            inner.addView(textGroup);
            inner.addView(btnGroup);
            card.addView(inner);
            layoutVehicles.addView(card);
        }
        cursor.close();
    }
}