package com.cnsc.carcare;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import java.util.Calendar;

public class ReminderActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;
    LinearLayout layoutReminders;
    EditText etReminderType, etReminderNote, etDueDate, etDueOdometer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        overridePendingTransition(0, 0);
        super.onCreate(savedInstanceState);

        // CRITICAL: Ensure this filename matches your XML (activity_reminders or activity_reminder)
        setContentView(R.layout.activity_reminder);

        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        layoutReminders = findViewById(R.id.layoutReminders);
        etReminderType = findViewById(R.id.etReminderType);
        etReminderNote = findViewById(R.id.etReminderNote);
        etDueDate = findViewById(R.id.etDueDate);
        etDueOdometer = findViewById(R.id.etDueOdometer);

        // Date Picker Setup
        etDueDate.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, y, m, d) ->
                    etDueDate.setText(y + "-" + (m + 1) + "-" + d),
                    c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        // FIXED ADD BUTTON LOGIC
        findViewById(R.id.btnAddReminder).setOnClickListener(v -> {
            String type = etReminderType.getText().toString().trim();
            String note = etReminderNote.getText().toString().trim();
            String date = etDueDate.getText().toString().trim();
            String odoInput = etDueOdometer.getText().toString().trim();

            if (type.isEmpty()) {
                Toast.makeText(this, "Please enter a reminder type", Toast.LENGTH_SHORT).show();
                return;
            }

            // Get active vehicle from session
            int vehicleId = session.getActiveVehicleId();
            if (vehicleId == -1) {
                Toast.makeText(this, "Select a vehicle in the Garage first!", Toast.LENGTH_LONG).show();
                return;
            }

            int odo = 0;
            try {
                if (!odoInput.isEmpty()) {
                    odo = Integer.parseInt(odoInput);
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid odometer number", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save to Database
            boolean success = db.addReminder(vehicleId, type, note, date, odo);

            if (success) {
                Toast.makeText(this, "Reminder Added!", Toast.LENGTH_SHORT).show();
                // Clear fields for next entry
                etReminderType.setText("");
                etReminderNote.setText("");
                etDueDate.setText("");
                etDueOdometer.setText("");
                loadReminders(); // Refresh the list below
            } else {
                Toast.makeText(this, "Database Error: Could not save.", Toast.LENGTH_SHORT).show();
            }
        });

        setupNavigation();
        loadReminders();
    }

    private void loadReminders() {
        if (layoutReminders == null) return;
        layoutReminders.removeAllViews();
        int vehicleId = session.getActiveVehicleId();

        if (vehicleId == -1) {
            TextView tv = new TextView(this);
            tv.setText("No active vehicle selected.");
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, 50, 0, 0);
            layoutReminders.addView(tv);
            return;
        }

        Cursor cursor = db.getRemindersByVehicle(vehicleId);

        if (cursor == null || cursor.getCount() == 0) {
            TextView tv = new TextView(this);
            tv.setText("No upcoming reminders.");
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, 50, 0, 0);
            layoutReminders.addView(tv);
            return;
        }

        while (cursor.moveToNext()) {
            final int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String type = cursor.getString(cursor.getColumnIndexOrThrow("type"));
            String note = cursor.getString(cursor.getColumnIndexOrThrow("note"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("due_date"));

            CardView card = new CardView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 0, 32);
            card.setLayoutParams(params);
            card.setRadius(24f);
            card.setCardElevation(6f);

            LinearLayout inner = new LinearLayout(this);
            inner.setPadding(40, 40, 40, 40);
            inner.setOrientation(LinearLayout.VERTICAL);

            TextView title = new TextView(this);
            title.setText("🔔 " + type);
            title.setTextSize(18f); // Changed to float
            title.setTextColor(getResources().getColor(R.color.blue_dark));
            title.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView info = new TextView(this);
            info.setText("Due: " + date + (note.isEmpty() ? "" : "\nNote: " + note));
            info.setPadding(0, 10, 0, 24);
            info.setTextColor(android.graphics.Color.GRAY);

            LinearLayout buttonLayout = new LinearLayout(this);
            buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(0, 120, 1f);

            // COMPLETE BUTTON
            Button btnComplete = new Button(this);
            btnComplete.setText("Complete");
            btnComplete.setTextSize(12f); // FIXED: Removed 'sp'
            btnComplete.setAllCaps(false);
            btnComplete.setBackgroundResource(R.drawable.rounded_button_blue);
            btnComplete.setTextColor(android.graphics.Color.WHITE);
            btnParams.setMargins(0, 0, 10, 0);
            btnComplete.setLayoutParams(btnParams);
            btnComplete.setOnClickListener(v -> {
                db.markReminderDone(id);
                loadReminders();
                Toast.makeText(this, "Maintenance completed!", Toast.LENGTH_SHORT).show();
            });

            // DELETE BUTTON
            Button btnDelete = new Button(this);
            btnDelete.setText("Delete");
            btnDelete.setTextSize(12f); // FIXED: Removed 'sp'
            btnDelete.setAllCaps(false);
            // Safety check: if you haven't made the XML yet, this prevents a crash
            try {
                btnDelete.setBackgroundResource(R.drawable.rounded_button_gray);
            } catch (Exception e) {
                btnDelete.setBackgroundColor(android.graphics.Color.GRAY);
            }
            btnDelete.setTextColor(android.graphics.Color.WHITE);
            btnDelete.setLayoutParams(new LinearLayout.LayoutParams(0, 120, 1f));
            btnDelete.setOnClickListener(v -> {
                db.deleteReminder(id);
                loadReminders();
                Toast.makeText(this, "Reminder removed", Toast.LENGTH_SHORT).show();
            });

            buttonLayout.addView(btnComplete);
            buttonLayout.addView(btnDelete);
            inner.addView(title);
            inner.addView(info);
            inner.addView(buttonLayout);
            card.addView(inner);
            layoutReminders.addView(card);
        }
        cursor.close();
    }

    private void setupNavigation() {
        // Nav Home
        findViewById(R.id.btnNavHome).setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        // Nav History
        findViewById(R.id.btnNavHistory).setOnClickListener(v -> {
            startActivity(new Intent(this, HistoryActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        // Nav Garage
        findViewById(R.id.btnNavVehicles).setOnClickListener(v -> {
            startActivity(new Intent(this, VehicleManagementActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        // Nav FAB (Add Expense)
        findViewById(R.id.btnNavAddExpense).setOnClickListener(v -> {
            startActivity(new Intent(this, AddExpenseActivity.class));
            overridePendingTransition(0, 0);
        });
    }
}