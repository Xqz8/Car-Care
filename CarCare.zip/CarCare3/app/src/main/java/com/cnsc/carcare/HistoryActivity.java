package com.cnsc.carcare;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import java.util.Locale;

public class HistoryActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;
    LinearLayout layoutHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        overridePendingTransition(0, 0);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // --- BACK BUTTON LOGIC ---
        // Find the back button from the revised activity_history.xml
        ImageButton btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                finish(); // Returns to the previous screen (Dashboard)
            });
        }

        // REMOVED: getSupportActionBar() block because we are using a
        // custom header in the XML layout.

        db = new DatabaseHelper(this);
        session = new SessionManager(this);
        layoutHistory = findViewById(R.id.layoutHistory);

        setupNavigation();
        setupFilterSpinner();

        loadHistory(null);
    }

    private void setupFilterSpinner() {
        Spinner spinner = findViewById(R.id.spinnerFilter);
        String[] filters = {"All", "Fuel", "Maintenance", "Repair", "Insurance", "Registration"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, filters);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String filter = filters[position];
                if (filter.equals("All")) loadHistory(null);
                else loadHistory(filter);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupNavigation() {
        // HOME
        findViewById(R.id.btnNavHome).setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        // HISTORY (Refresh logic)
        findViewById(R.id.btnNavHistory).setOnClickListener(v -> {
            loadHistory(null);
            Toast.makeText(this, "History Refreshed", Toast.LENGTH_SHORT).show();
        });

        // REMINDERS
        findViewById(R.id.btnNavReminders).setOnClickListener(v -> {
            startActivity(new Intent(this, ReminderActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        // GARAGE
        findViewById(R.id.btnNavVehicles).setOnClickListener(v -> {
            startActivity(new Intent(this, VehicleManagementActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        // FAB
        findViewById(R.id.btnNavAddExpense).setOnClickListener(v -> {
            startActivity(new Intent(this, AddExpenseActivity.class));
            overridePendingTransition(0, 0);
        });
    }

    private void loadHistory(String category) {
        layoutHistory.removeAllViews();
        int vehicleId = session.getActiveVehicleId();

        Cursor cursor;
        if (category == null) cursor = db.getExpensesByVehicle(vehicleId);
        else cursor = db.getExpensesByCategory(vehicleId, category);

        if (cursor == null || cursor.getCount() == 0) {
            TextView empty = new TextView(this);
            empty.setText("No expenses found");
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, 80, 0, 0);
            layoutHistory.addView(empty);
            if (cursor != null) cursor.close();
            return;
        }

        while (cursor.moveToNext()) {
            final int id = cursor.getInt(0);
            String cat = cursor.getString(2);
            double amount = cursor.getDouble(3);
            String date = cursor.getString(4);
            int odo = cursor.getInt(5);

            CardView card = new CardView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 15, 0, 15);
            card.setLayoutParams(params);
            card.setRadius(35f);
            card.setCardElevation(4f);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(45, 35, 45, 35);
            row.setGravity(Gravity.CENTER_VERTICAL);

            LinearLayout left = new LinearLayout(this);
            left.setOrientation(LinearLayout.VERTICAL);
            left.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvCat = new TextView(this);
            tvCat.setText(getCategoryEmoji(cat) + " " + cat);
            tvCat.setTextSize(17f);
            tvCat.setTypeface(null, android.graphics.Typeface.BOLD);
            tvCat.setTextColor(getResources().getColor(R.color.blue_dark));

            TextView tvDate = new TextView(this);
            tvDate.setText(date + (odo > 0 ? " • " + odo + " km" : ""));
            tvDate.setTextColor(android.graphics.Color.GRAY);

            left.addView(tvCat);
            left.addView(tvDate);

            LinearLayout right = new LinearLayout(this);
            right.setOrientation(LinearLayout.VERTICAL);
            right.setGravity(Gravity.END);

            TextView tvAmount = new TextView(this);
            tvAmount.setText(String.format(Locale.getDefault(), "₱%.2f", amount));
            tvAmount.setTextSize(17f);
            tvAmount.setTypeface(null, android.graphics.Typeface.BOLD);
            tvAmount.setTextColor(getResources().getColor(R.color.blue_primary));

            // Custom styled delete button
            TextView btnDel = new TextView(this);
            btnDel.setText("🗑 Delete");
            btnDel.setPadding(10, 10, 0, 0);
            btnDel.setTextColor(android.graphics.Color.RED);
            btnDel.setTextSize(12f);
            btnDel.setOnClickListener(v -> {
                db.deleteExpense(id);
                Toast.makeText(this, "Expense deleted", Toast.LENGTH_SHORT).show();
                loadHistory(category);
            });

            right.addView(tvAmount);
            right.addView(btnDel);

            row.addView(left);
            row.addView(right);
            card.addView(row);
            layoutHistory.addView(card);
        }
        cursor.close();
    }

    private String getCategoryEmoji(String category) {
        switch (category != null ? category : "") {
            case "Fuel": return "⛽";
            case "Maintenance": return "🔧";
            case "Repair": return "🛠️";
            case "Insurance": return "🛡️";
            case "Registration": return "📋";
            default: return "💰";
        }
    }
}