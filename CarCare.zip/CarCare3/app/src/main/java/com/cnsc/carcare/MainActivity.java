package com.cnsc.carcare;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

// --- CHART IMPORTS ---
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
// ---------------------

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;

    // Chart Variables
    private PieChart pieChart;
    private BarChart barChart;
    private LinearLayout layoutHomeReminders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        // Bind Views
        pieChart = findViewById(R.id.homePieChart);
        barChart = findViewById(R.id.homeBarChart);
        layoutHomeReminders = findViewById(R.id.layoutHomeReminders);

        setupButtons();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardData();
    }

    private void loadDashboardData() {
        int vehicleId = session.getActiveVehicleId();

        // 1. Greeting & User Info
        TextView tvGreeting = findViewById(R.id.tvGreeting);
        TextView tvUserName = findViewById(R.id.tvUserName);

        if (tvGreeting != null) {
            int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            if (hour < 12) tvGreeting.setText("Good Morning 👋");
            else if (hour < 18) tvGreeting.setText("Good Afternoon 👋");
            else tvGreeting.setText("Good Evening 👋");
        }

        if (tvUserName != null) {
            tvUserName.setText(session.getUserName());
        }

        // 2. Vehicle & Analytics Logic
        if (vehicleId != -1) {
            Cursor v = db.getVehicleById(vehicleId);
            if (v != null && v.moveToFirst()) {
                TextView tvVehicleName = findViewById(R.id.tvVehicleName);
                TextView tvVehicleInfo = findViewById(R.id.tvVehicleInfo);
                TextView tvOdometer = findViewById(R.id.tvOdometer);

                if (tvVehicleName != null) tvVehicleName.setText(v.getString(2));
                if (tvVehicleInfo != null) {
                    String info = v.getString(4) + " " + v.getString(5) + " • " + v.getString(6);
                    tvVehicleInfo.setText(info);
                }
                if (tvOdometer != null) tvOdometer.setText("Odometer: " + v.getInt(8) + " km");
            }
            if (v != null) v.close();

            // Stats Cards
            updateQuickStats(vehicleId);

            // Upcoming Reminders Section
            displayUpcomingReminders(vehicleId);

            // Load Charts
            setupPieChart(vehicleId);
            setupBarChart(vehicleId);
        } else {
            // No vehicle selected state
            if (layoutHomeReminders != null) {
                layoutHomeReminders.removeAllViews();
                TextView tv = new TextView(this);
                tv.setText("Go to Garage to select a vehicle.");
                layoutHomeReminders.addView(tv);
            }
        }
    }

    private void updateQuickStats(int vehicleId) {
        TextView tvTotalExpenses = findViewById(R.id.tvTotalExpenses);
        if (tvTotalExpenses != null) {
            double total = db.getTotalExpensesByVehicle(vehicleId);
            tvTotalExpenses.setText(String.format(Locale.getDefault(), "₱%.2f", total));
        }

        TextView tvMonthlyExpenses = findViewById(R.id.tvMonthlyExpenses);
        if (tvMonthlyExpenses != null) {
            String currentMonth = new SimpleDateFormat("yyyy-MM", Locale.getDefault())
                    .format(Calendar.getInstance().getTime());
            double monthly = db.getMonthlyExpenses(vehicleId, currentMonth);
            tvMonthlyExpenses.setText(String.format(Locale.getDefault(), "₱%.2f", monthly));
        }

        TextView tvFuelEfficiency = findViewById(R.id.tvFuelEfficiency);
        if (tvFuelEfficiency != null) {
            double avgEfficiency = db.getAverageFuelEfficiency(vehicleId);
            tvFuelEfficiency.setText(String.format(Locale.getDefault(), "%.1f km/L", avgEfficiency));
        }

        TextView tvReminderCount = findViewById(R.id.tvReminderCount);
        if (tvReminderCount != null) {
            Cursor reminders = db.getRemindersByVehicle(vehicleId);
            tvReminderCount.setText(String.valueOf(reminders != null ? reminders.getCount() : 0));
            if (reminders != null) reminders.close();
        }
    }

    private void displayUpcomingReminders(int vehicleId) {
        if (layoutHomeReminders == null) return;
        layoutHomeReminders.removeAllViews();

        Cursor cursor = db.getRemindersByVehicle(vehicleId);

        if (cursor != null && cursor.getCount() > 0) {
            int count = 0;
            while (cursor.moveToNext() && count < 2) {
                String type = cursor.getString(cursor.getColumnIndexOrThrow("type"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("due_date"));

                TextView tv = new TextView(this);
                tv.setText("• " + type + " (Due: " + date + ")");
                tv.setTextColor(getResources().getColor(R.color.blue_dark));
                tv.setPadding(0, 8, 0, 8);
                tv.setTextSize(14f);
                layoutHomeReminders.addView(tv);
                count++;
            }
            cursor.close();
        } else {
            TextView tv = new TextView(this);
            tv.setText("No upcoming maintenance tasks.");
            tv.setTextColor(Color.GRAY);
            layoutHomeReminders.addView(tv);
        }
    }

    private void setupPieChart(int vehicleId) {
        if (pieChart == null) return;
        ArrayList<PieEntry> entries = new ArrayList<>();
        HashMap<String, Float> categoryMap = new HashMap<>();

        Cursor cursor = db.getExpensesByVehicle(vehicleId);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String category = cursor.getString(2);
                float amount = cursor.getFloat(3);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    categoryMap.put(category, categoryMap.getOrDefault(category, 0f) + amount);
                }
            }
            cursor.close();
        }

        for (Map.Entry<String, Float> entry : categoryMap.entrySet()) {
            entries.add(new PieEntry(entry.getValue(), entry.getKey()));
        }

        PieDataSet dataSet = new PieDataSet(entries, "");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(10f);

        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PercentFormatter(pieChart));

        pieChart.setData(data);
        pieChart.setTouchEnabled(false);
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.getLegend().setEnabled(false);
        pieChart.setHoleRadius(40f);
        pieChart.animateY(1000);
        pieChart.invalidate();
    }

    private void setupBarChart(int vehicleId) {
        if (barChart == null) return;
        ArrayList<BarEntry> entries = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();

        for (int i = 3; i >= 0; i--) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MONTH, -i);
            String monthQuery = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(cal.getTime());
            String monthName = new SimpleDateFormat("MMM", Locale.getDefault()).format(cal.getTime());

            float monthlyTotal = (float) db.getMonthlyExpenses(vehicleId, monthQuery);
            entries.add(new BarEntry(3 - i, monthlyTotal));
            labels.add(monthName);
        }

        BarDataSet dataSet = new BarDataSet(entries, "Spending");
        dataSet.setColors(ColorTemplate.LIBERTY_COLORS);

        BarData data = new BarData(dataSet);
        data.setBarWidth(0.6f);
        barChart.setData(data);
        barChart.setTouchEnabled(false);
        barChart.getDescription().setEnabled(false);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);

        barChart.getAxisRight().setEnabled(false);
        barChart.animateY(1000);
        barChart.invalidate();
    }

    private void setupButtons() {
        // Navigation logic with transition fixes
        findViewById(R.id.btnNavAddExpense).setOnClickListener(v -> {
            startActivity(new Intent(this, AddExpenseActivity.class));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.btnNavHome).setOnClickListener(v -> {
            loadDashboardData();
            Toast.makeText(this, "Dashboard Updated", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btnNavHistory).setOnClickListener(v -> {
            startActivity(new Intent(this, HistoryActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.btnNavReminders).setOnClickListener(v -> {
            startActivity(new Intent(this, ReminderActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        findViewById(R.id.btnNavVehicles).setOnClickListener(v -> {
            startActivity(new Intent(this, VehicleManagementActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });

        if (findViewById(R.id.btnSettings) != null) {
            findViewById(R.id.btnSettings).setOnClickListener(v -> {
                startActivity(new Intent(this, SettingsActivity.class));
                overridePendingTransition(0, 0);
            });
        }
    }
}