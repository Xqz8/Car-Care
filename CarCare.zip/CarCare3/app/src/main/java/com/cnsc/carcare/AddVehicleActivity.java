package com.cnsc.carcare;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem; // Required for ActionBar back button
import android.widget.*;
import androidx.appcompat.app.AlertDialog; // For the confirmation popup
import androidx.appcompat.app.AppCompatActivity;

public class AddVehicleActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vehicle);

        // --- 1. ACTION BAR BACK BUTTON ---
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Add Vehicle"); // Fixed title from "Add Expense"
        }

        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        // Bind Views
        EditText etName = findViewById(R.id.etVehicleName);
        Spinner spinnerType = findViewById(R.id.spinnerType);
        EditText etBrand = findViewById(R.id.etBrand);
        EditText etModel = findViewById(R.id.etModel);
        EditText etYear = findViewById(R.id.etYear);
        EditText etPlate = findViewById(R.id.etPlate);
        EditText etOdometer = findViewById(R.id.etOdometer);
        Button btnSave = findViewById(R.id.btnSaveVehicle);

        // --- 2. CUSTOM XML BACK BUTTON ---
        ImageButton btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // Save Logic with Confirmation
        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            if (name.isEmpty() || etBrand.getText().toString().isEmpty()) {
                Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Show Confirmation Dialog before saving
            new AlertDialog.Builder(this)
                    .setTitle("Confirm")
                    .setMessage("Save " + name + " to your garage?")
                    .setPositiveButton("Yes", (dialog, which) -> performSave(etName, spinnerType, etBrand, etModel, etYear, etPlate, etOdometer))
                    .setNegativeButton("No", null)
                    .show();
        });
    }

    // Separated save logic for cleanliness
    private void performSave(EditText etName, Spinner spinnerType, EditText etBrand,
                             EditText etModel, EditText etYear, EditText etPlate, EditText etOdometer) {

        String name = etName.getText().toString().trim();
        String type = spinnerType.getSelectedItem().toString();
        String brand = etBrand.getText().toString().trim();
        String model = etModel.getText().toString().trim();
        String year = etYear.getText().toString().trim();
        String plate = etPlate.getText().toString().trim();
        String odoStr = etOdometer.getText().toString().trim();

        int odometer = odoStr.isEmpty() ? 0 : Integer.parseInt(odoStr);
        int userId = session.getUserId();

        long vehicleId = db.addVehicle(userId, name, type, brand, model, year, plate, odometer, "");

        if (vehicleId != -1) {
            session.setActiveVehicle((int) vehicleId);
            Toast.makeText(this, "Vehicle saved! 🚗", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Error saving vehicle", Toast.LENGTH_SHORT).show();
        }
    }

    // --- 3. HANDLE ACTION BAR BACK CLICK ---
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Closes activity when top-left arrow is clicked
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}