package com.cnsc.carcare;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.Locale;

public class AddExpenseActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        // --- ACTION BAR SETUP ---
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Add Expense");
        }

        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        // Bind Views
        Spinner spinnerCategory = findViewById(R.id.spinnerCategory);
        EditText etAmount = findViewById(R.id.etAmount);
        EditText etDate = findViewById(R.id.etDate);
        EditText etOdometer = findViewById(R.id.etOdometer);
        EditText etNotes = findViewById(R.id.etNotes);
        Button btnSave = findViewById(R.id.btnSave);

        // --- CUSTOM BACK BUTTON (HEADER) ---
        ImageButton btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // Set today's date default
        Calendar cal = Calendar.getInstance();
        etDate.setText(String.format(Locale.getDefault(), "%d-%02d-%02d",
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)));

        // Date picker listener
        etDate.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, day) -> {
                etDate.setText(String.format(Locale.getDefault(), "%d-%02d-%02d", year, month + 1, day));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        // --- SAVE BUTTON WITH DIALOG ---
        btnSave.setOnClickListener(v -> {
            String amountStr = etAmount.getText().toString().trim();
            String category = spinnerCategory.getSelectedItem().toString();

            if (amountStr.isEmpty()) {
                etAmount.setError("Please enter an amount");
                return;
            }

            new AlertDialog.Builder(this)
                    .setTitle("Confirm Expense")
                    .setMessage("Save ₱" + amountStr + " for " + category + "?")
                    .setPositiveButton("Yes, Save", (dialog, which) -> {
                        performSave(spinnerCategory, etAmount, etDate, etOdometer, etNotes);
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                    .show();
        });
    }

    private void performSave(Spinner spinnerCategory, EditText etAmount, EditText etDate,
                             EditText etOdometer, EditText etNotes) {
        try {
            int vehicleId = session.getActiveVehicleId();
            String odoStr = etOdometer.getText().toString().trim();

            // --- NEW: ODOMETER VALIDATION LOGIC ---
            int currentOdo = db.getVehicleOdometer(vehicleId); // Ensure this method exists in DatabaseHelper
            int inputOdometer = odoStr.isEmpty() ? 0 : Integer.parseInt(odoStr);

            if (!odoStr.isEmpty() && inputOdometer < currentOdo) {
                // Show error and stop the save process
                etOdometer.setError("Invalid: Current mileage is " + currentOdo + " km");
                Toast.makeText(this, "Odometer cannot be lower than current reading!", Toast.LENGTH_LONG).show();
                return; // EXITS the method; nothing is saved
            }
            // ---------------------------------------

            String category = spinnerCategory.getSelectedItem().toString();
            String amountStr = etAmount.getText().toString().trim();
            String date = etDate.getText().toString().trim();
            String notes = etNotes.getText().toString().trim();

            double amount = Double.parseDouble(amountStr);

            long result = db.insertExpense(vehicleId, category, amount, date, inputOdometer, notes, "");

            if (result != -1) {
                if (inputOdometer > 0) db.updateVehicleOdometer(vehicleId, inputOdometer);
                Toast.makeText(this, "Expense saved! ✅", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Error saving expense", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid number format", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}