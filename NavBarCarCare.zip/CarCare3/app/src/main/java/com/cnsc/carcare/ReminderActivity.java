package com.cnsc.carcare;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import java.util.Calendar;
import java.util.Locale;

public class ReminderActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;
    LinearLayout layoutReminders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);

        // --- POSITION 1: Inside onCreate ---
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Add Expense");
        }
        // ------------------------------------

        db = new DatabaseHelper(this);
        session = new SessionManager(this);
        layoutReminders = findViewById(R.id.layoutReminders);

        EditText etType = findViewById(R.id.etReminderType);
        EditText etNote = findViewById(R.id.etReminderNote);
        EditText etDueDate = findViewById(R.id.etDueDate);
        EditText etDueOdo = findViewById(R.id.etDueOdometer);

        // Date picker
        Calendar cal = Calendar.getInstance();
        etDueDate.setText(String.format(Locale.getDefault(), "%d-%02d-%02d",
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)));
        etDueDate.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, day) ->
                    etDueDate.setText(String.format(Locale.getDefault(), "%d-%02d-%02d", year, month + 1, day)),
                    c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        findViewById(R.id.btnAddReminder).setOnClickListener(v -> {
            String type = etType.getText().toString().trim();
            String note = etNote.getText().toString().trim();
            String date = etDueDate.getText().toString().trim();
            String odoStr = etDueOdo.getText().toString().trim();

            if (type.isEmpty()) {
                Toast.makeText(this, "Please enter reminder type", Toast.LENGTH_SHORT).show();
                return;
            }

            int odo = odoStr.isEmpty() ? 0 : Integer.parseInt(odoStr);
            int vehicleId = session.getActiveVehicleId();

            long result = db.addReminder(vehicleId, type, note, date, odo);
            if (result != -1) {
                etType.setText("");
                etNote.setText("");
                etDueOdo.setText("");
                Toast.makeText(this, "Reminder added! ✅", Toast.LENGTH_SHORT).show();
                loadReminders();
            }
        });

        loadReminders();
    }

    private void loadReminders() {
        layoutReminders.removeAllViews();
        int vehicleId = session.getActiveVehicleId();
        Cursor cursor = db.getRemindersByVehicle(vehicleId);

        if (cursor.getCount() == 0) {
            TextView empty = new TextView(this);
            empty.setText("No upcoming reminders 🎉");
            empty.setTextColor(getResources().getColor(R.color.gray_medium));
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, 20, 0, 20);
            layoutReminders.addView(empty);
            return;
        }

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String type = cursor.getString(2);
            String note = cursor.getString(3);
            String dueDate = cursor.getString(4);
            int dueOdo = cursor.getInt(5);

            // Create card for each reminder
            CardView card = new CardView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 0, 12);
            card.setLayoutParams(params);
            card.setRadius(32f);
            card.setCardElevation(4f);

            LinearLayout inner = new LinearLayout(this);
            inner.setOrientation(LinearLayout.HORIZONTAL);
            inner.setPadding(32, 24, 32, 24);

            LinearLayout textGroup = new LinearLayout(this);
            textGroup.setOrientation(LinearLayout.VERTICAL);
            textGroup.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvType = new TextView(this);
            tvType.setText("🔔 " + type);
            tvType.setTextSize(16f);
            tvType.setTextColor(getResources().getColor(R.color.blue_dark));
            tvType.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView tvDate = new TextView(this);
            tvDate.setText("Due: " + dueDate + (dueOdo > 0 ? " or " + dueOdo + " km" : ""));
            tvDate.setTextColor(getResources().getColor(R.color.gray_medium));
            tvDate.setTextSize(13f);

            if (!note.isEmpty()) {
                TextView tvNote = new TextView(this);
                tvNote.setText(note);
                tvNote.setTextColor(getResources().getColor(R.color.gray_dark));
                tvNote.setTextSize(12f);
                textGroup.addView(tvType);
                textGroup.addView(tvDate);
                textGroup.addView(tvNote);
            } else {
                textGroup.addView(tvType);
                textGroup.addView(tvDate);
            }

            Button btnDone = new Button(this);
            btnDone.setText("Done");
            btnDone.setTextColor(getResources().getColor(R.color.white));
            btnDone.setBackground(getResources().getDrawable(R.drawable.rounded_button_blue));
            btnDone.setOnClickListener(v -> {
                db.markReminderDone(id);
                Toast.makeText(this, "Marked as done!", Toast.LENGTH_SHORT).show();
                loadReminders();
            });

            inner.addView(textGroup);
            inner.addView(btnDone);
            card.addView(inner);
            layoutReminders.addView(card);
        }
        cursor.close();
    }
}