package com.cnsc.carcare;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class VehicleManagementActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;
    LinearLayout layoutVehicles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_management);

        db = new DatabaseHelper(this);
        session = new SessionManager(this);
        layoutVehicles = findViewById(R.id.layoutVehicles);

        findViewById(R.id.btnAddVehicle).setOnClickListener(v ->
                startActivity(new Intent(this, AddVehicleActivity.class)));

        loadVehicles();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadVehicles();
    }

    private void loadVehicles() {
        layoutVehicles.removeAllViews();
        int userId = session.getUserId();
        int activeId = session.getActiveVehicleId();
        Cursor cursor = db.getVehiclesByUser(userId);

        if (cursor.getCount() == 0) {
            TextView empty = new TextView(this);
            empty.setText("No vehicles yet. Tap + Add to get started!");
            empty.setGravity(Gravity.CENTER);
            empty.setTextColor(getResources().getColor(R.color.gray_medium));
            empty.setPadding(0, 40, 0, 0);
            layoutVehicles.addView(empty);
            return;
        }

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(2);
            String type = cursor.getString(3);
            String brand = cursor.getString(4);
            String model = cursor.getString(5);
            String year = cursor.getString(6);
            int odometer = cursor.getInt(8);
            boolean isActive = (id == activeId);

            CardView card = new CardView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 0, 12);
            card.setLayoutParams(params);
            card.setRadius(28f);
            card.setCardElevation(isActive ? 8f : 4f);

            LinearLayout inner = new LinearLayout(this);
            inner.setOrientation(LinearLayout.HORIZONTAL);
            inner.setPadding(28, 20, 28, 20);
            inner.setGravity(Gravity.CENTER_VERTICAL);
            if (isActive) inner.setBackgroundResource(R.color.blue_accent);

            LinearLayout textGroup = new LinearLayout(this);
            textGroup.setOrientation(LinearLayout.VERTICAL);
            textGroup.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvName = new TextView(this);
            tvName.setText((isActive ? "✅ " : "🚗 ") + name);
            tvName.setTextSize(17f);
            tvName.setTextColor(getResources().getColor(R.color.blue_dark));
            tvName.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView tvInfo = new TextView(this);
            tvInfo.setText(brand + " " + model + " " + year + " • " + odometer + " km");
            tvInfo.setTextColor(getResources().getColor(R.color.gray_medium));
            tvInfo.setTextSize(13f);

            textGroup.addView(tvName);
            textGroup.addView(tvInfo);

            LinearLayout btnGroup = new LinearLayout(this);
            btnGroup.setOrientation(LinearLayout.HORIZONTAL);

            if (!isActive) {
                Button btnSelect = new Button(this);
                btnSelect.setText("Select");
                btnSelect.setBackground(getResources().getDrawable(R.drawable.rounded_button_blue));
                btnSelect.setTextColor(getResources().getColor(R.color.white));
                btnSelect.setOnClickListener(v -> {
                    session.setActiveVehicle(id);
                    Toast.makeText(this, name + " selected!", Toast.LENGTH_SHORT).show();
                    loadVehicles();
                });
                btnGroup.addView(btnSelect);
            }

            Button btnDelete = new Button(this);
            btnDelete.setText("🗑");
            btnDelete.setBackground(null);
            btnDelete.setTextSize(18f);
            btnDelete.setOnClickListener(v -> {
                db.deleteVehicle(id);
                if (isActive) session.setActiveVehicle(-1);
                Toast.makeText(this, "Vehicle deleted", Toast.LENGTH_SHORT).show();
                loadVehicles();
            });
            btnGroup.addView(btnDelete);

            inner.addView(textGroup);
            inner.addView(btnGroup);
            card.addView(inner);
            layoutVehicles.addView(card);
        }
        cursor.close();
    }
}