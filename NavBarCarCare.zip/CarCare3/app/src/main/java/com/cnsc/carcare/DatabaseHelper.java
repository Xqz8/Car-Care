package com.cnsc.carcare;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "carcare.db";
    private static final int DB_VERSION = 3;

    // Table names
    public static final String TABLE_VEHICLES = "vehicles";
    public static final String TABLE_EXPENSES = "expenses";
    public static final String TABLE_FUEL = "fuel_logs";
    public static final String TABLE_REMINDERS = "reminders";
    public static final String TABLE_USERS = "users";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Users table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "email TEXT UNIQUE," +
                "password TEXT," +
                "created_at TEXT)");

        // Vehicles table
        db.execSQL("CREATE TABLE " + TABLE_VEHICLES + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER," +
                "name TEXT," +
                "type TEXT," +
                "brand TEXT," +
                "model TEXT," +
                "year TEXT," +
                "plate TEXT," +
                "odometer INTEGER," +
                "image_path TEXT," +
                "created_at TEXT)");

        // Expenses table
        db.execSQL("CREATE TABLE " + TABLE_EXPENSES + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "vehicle_id INTEGER," +
                "category TEXT," +
                "amount REAL," +
                "date TEXT," +
                "odometer INTEGER," +
                "notes TEXT," +
                "receipt_image TEXT," +
                "created_at TEXT)");

        // Fuel logs table
        db.execSQL("CREATE TABLE " + TABLE_FUEL + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "vehicle_id INTEGER," +
                "liters REAL," +
                "total_cost REAL," +
                "price_per_liter REAL," +
                "odometer INTEGER," +
                "date TEXT," +
                "efficiency REAL," +
                "created_at TEXT)");

        // Reminders table
        db.execSQL("CREATE TABLE " + TABLE_REMINDERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "vehicle_id INTEGER," +
                "type TEXT," +
                "note TEXT," +
                "due_date TEXT," +
                "due_odometer INTEGER," +
                "is_done INTEGER DEFAULT 0," +
                "created_at TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VEHICLES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXPENSES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FUEL);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REMINDERS);
        onCreate(db);
    }

    // ==================== USER METHODS ====================

    public boolean registerUser(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("email", email);
        values.put("password", password);
        values.put("created_at", getCurrentDateTime());
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public Cursor loginUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USERS +
                " WHERE email=? AND password=?", new String[]{email, password});
    }

    public Cursor getUserById(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE id=?",
                new String[]{String.valueOf(userId)});
    }

    // ==================== VEHICLE METHODS ====================

    public long addVehicle(int userId, String name, String type, String brand,
                           String model, String year, String plate,
                           int odometer, String imagePath) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("name", name);
        values.put("type", type);
        values.put("brand", brand);
        values.put("model", model);
        values.put("year", year);
        values.put("plate", plate);
        values.put("odometer", odometer);
        values.put("image_path", imagePath);
        values.put("created_at", getCurrentDateTime());
        return db.insert(TABLE_VEHICLES, null, values);
    }

    public Cursor getVehiclesByUser(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_VEHICLES + " WHERE user_id=?",
                new String[]{String.valueOf(userId)});
    }

    public Cursor getVehicleById(int vehicleId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_VEHICLES + " WHERE id=?",
                new String[]{String.valueOf(vehicleId)});
    }

    public boolean updateVehicleOdometer(int vehicleId, int newOdometer) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("odometer", newOdometer);
        int rows = db.update(TABLE_VEHICLES, values, "id=?",
                new String[]{String.valueOf(vehicleId)});
        return rows > 0;
    }

    public boolean deleteVehicle(int vehicleId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_EXPENSES, "vehicle_id=?", new String[]{String.valueOf(vehicleId)});
        db.delete(TABLE_FUEL, "vehicle_id=?", new String[]{String.valueOf(vehicleId)});
        db.delete(TABLE_REMINDERS, "vehicle_id=?", new String[]{String.valueOf(vehicleId)});
        int rows = db.delete(TABLE_VEHICLES, "id=?", new String[]{String.valueOf(vehicleId)});
        return rows > 0;
    }

    // ==================== EXPENSE METHODS ====================

    public long insertExpense(int vehicleId, String category, double amount,
                           String date, int odometer, String notes, String receiptImage) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("vehicle_id", vehicleId);
        values.put("category", category);
        values.put("amount", amount);
        values.put("date", date);
        values.put("odometer", odometer);
        values.put("notes", notes);
        values.put("receipt_image", receiptImage);
        values.put("created_at", getCurrentDateTime());
        return db.insert(TABLE_EXPENSES, null, values);
    }

    public Cursor getAllExpenses() {
        SQLiteDatabase db = this.getReadableDatabase();
        // This selects everything from the expenses table
        return db.rawQuery("SELECT * FROM " + TABLE_EXPENSES + " ORDER BY date DESC", null);
    }

    public Cursor getExpensesByVehicle(int vehicleId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_EXPENSES +
                        " WHERE vehicle_id=? ORDER BY date DESC",
                new String[]{String.valueOf(vehicleId)});
    }

    public Cursor getExpenseById(int expenseId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_EXPENSES + " WHERE id=?",
                new String[]{String.valueOf(expenseId)});
    }

    public double getTotalExpensesByVehicle(int vehicleId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT SUM(amount) FROM " + TABLE_EXPENSES +
                " WHERE vehicle_id=?", new String[]{String.valueOf(vehicleId)});
        double total = 0;
        if (c.moveToFirst()) total = c.getDouble(0);
        c.close();
        return total;
    }

    public double getMonthlyExpenses(int vehicleId, String month) {
        // month format: "2024-01"
        SQLiteDatabase db = this.getReadableDatabase();
        // Change the query in getMonthlyExpenses to this if your dates are messy:
        Cursor c = db.rawQuery("SELECT SUM(amount) FROM " + TABLE_EXPENSES +
                        " WHERE vehicle_id=? AND date LIKE '%" + month + "%'",
                new String[]{String.valueOf(vehicleId)});
        double total = 0;
        if (c.moveToFirst()) total = c.getDouble(0);
        c.close();
        return total;
    }

    public Cursor getExpensesByCategory(int vehicleId, String category) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_EXPENSES +
                        " WHERE vehicle_id=? AND category=? ORDER BY date DESC",
                new String[]{String.valueOf(vehicleId), category});
    }

    public boolean deleteExpense(int expenseId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_EXPENSES, "id=?",
                new String[]{String.valueOf(expenseId)}) > 0;
    }

    // ==================== FUEL METHODS ====================

    public long addFuelLog(int vehicleId, double liters, double totalCost,
                           double pricePerLiter, int odometer, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Calculate efficiency with previous log
        double efficiency = 0;
        Cursor prev = db.rawQuery("SELECT odometer, liters FROM " + TABLE_FUEL +
                        " WHERE vehicle_id=? ORDER BY odometer DESC LIMIT 1",
                new String[]{String.valueOf(vehicleId)});
        if (prev.moveToFirst()) {
            int prevOdo = prev.getInt(0);
            double prevLiters = prev.getDouble(1);
            if (odometer > prevOdo && prevLiters > 0) {
                efficiency = (odometer - prevOdo) / prevLiters;
            }
        }
        prev.close();

        ContentValues values = new ContentValues();
        values.put("vehicle_id", vehicleId);
        values.put("liters", liters);
        values.put("total_cost", totalCost);
        values.put("price_per_liter", pricePerLiter);
        values.put("odometer", odometer);
        values.put("date", date);
        values.put("efficiency", efficiency);
        values.put("created_at", getCurrentDateTime());
        return db.insert(TABLE_FUEL, null, values);
    }

    public Cursor getFuelLogsByVehicle(int vehicleId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_FUEL +
                        " WHERE vehicle_id=? ORDER BY date DESC",
                new String[]{String.valueOf(vehicleId)});
    }

    public double getAverageFuelEfficiency(int vehicleId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT AVG(efficiency) FROM " + TABLE_FUEL +
                        " WHERE vehicle_id=? AND efficiency > 0",
                new String[]{String.valueOf(vehicleId)});
        double avg = 0;
        if (c.moveToFirst()) avg = c.getDouble(0);
        c.close();
        return avg;
    }

    // ==================== REMINDER METHODS ====================

    public long addReminder(int vehicleId, String type, String note,
                            String dueDate, int dueOdometer) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("vehicle_id", vehicleId);
        values.put("type", type);
        values.put("note", note);
        values.put("due_date", dueDate);
        values.put("due_odometer", dueOdometer);
        values.put("is_done", 0);
        values.put("created_at", getCurrentDateTime());
        return db.insert(TABLE_REMINDERS, null, values);
    }

    public Cursor getRemindersByVehicle(int vehicleId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_REMINDERS +
                        " WHERE vehicle_id=? AND is_done=0 ORDER BY due_date ASC",
                new String[]{String.valueOf(vehicleId)});
    }

    public boolean markReminderDone(int reminderId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("is_done", 1);
        return db.update(TABLE_REMINDERS, values, "id=?",
                new String[]{String.valueOf(reminderId)}) > 0;
    }

    public boolean deleteReminder(int reminderId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_REMINDERS, "id=?",
                new String[]{String.valueOf(reminderId)}) > 0;
    }

    // ==================== UTILITY ====================

    private String getCurrentDateTime() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
                java.util.Locale.getDefault()).format(new java.util.Date());
    }
}