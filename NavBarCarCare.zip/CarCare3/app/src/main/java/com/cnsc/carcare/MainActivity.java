package com.cnsc.carcare;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        setupButtons();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardData();
    }

    private void loadDashboardData() {
        int userId = session.getUserId();
        int vehicleId = session.getActiveVehicleId();

        // Greeting
        TextView tvGreeting = findViewById(R.id.tvGreeting);
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 12) tvGreeting.setText("Good Morning 👋");
        else if (hour < 18) tvGreeting.setText("Good Afternoon 👋");
        else tvGreeting.setText("Good Evening 👋");

        // User name
        TextView tvUserName = findViewById(R.id.tvUserName);
        tvUserName.setText(session.getUserName());

        // Vehicle info
        if (vehicleId != -1) {
            Cursor v = db.getVehicleById(vehicleId);
            if (v.moveToFirst()) {
                ((TextView) findViewById(R.id.tvVehicleName)).setText(v.getString(2)); // name
                String info = v.getString(4) + " " + v.getString(5) + " • " + v.getString(6); // brand model year
                ((TextView) findViewById(R.id.tvVehicleInfo)).setText(info);
                ((TextView) findViewById(R.id.tvOdometer)).setText("Odometer: " + v.getInt(8) + " km");
            }
            v.close();

            // Total expenses
            double total = db.getTotalExpensesByVehicle(vehicleId);
            ((TextView) findViewById(R.id.tvTotalExpenses)).setText(
                    String.format(Locale.getDefault(), "₱%.2f", total));

            // Monthly expenses
            String currentMonth = new SimpleDateFormat("yyyy-MM", Locale.getDefault())
                    .format(Calendar.getInstance().getTime());
            double monthly = db.getMonthlyExpenses(vehicleId, currentMonth);
            ((TextView) findViewById(R.id.tvMonthlyExpenses)).setText(
                    String.format(Locale.getDefault(), "₱%.2f", monthly));

            // Fuel efficiency
            double avgEfficiency = db.getAverageFuelEfficiency(vehicleId);
            ((TextView) findViewById(R.id.tvFuelEfficiency)).setText(
                    String.format(Locale.getDefault(), "%.1f km/L", avgEfficiency));

            // Reminders count
            Cursor reminders = db.getRemindersByVehicle(vehicleId);
            ((TextView) findViewById(R.id.tvReminderCount)).setText(
                    String.valueOf(reminders.getCount()));
            reminders.close();
        }
    }

    private void setupButtons() {
        // 1. THE CENTER FLOATING BUTTON: Add Expense
        findViewById(R.id.btnNavAddExpense).setOnClickListener(v ->
                startActivity(new Intent(this, AddExpenseActivity.class)));

        // 2. LEFT SIDE: Home and History
        // Home button: Just refreshes the current dashboard data
        findViewById(R.id.btnNavHome).setOnClickListener(v -> {
            loadDashboardData();
            Toast.makeText(this, "Dashboard Updated", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btnNavHistory).setOnClickListener(v ->
                startActivity(new Intent(this, HistoryActivity.class)));

        // 3. RIGHT SIDE: Reminders and Vehicle Management
        findViewById(R.id.btnNavReminders).setOnClickListener(v ->
                startActivity(new Intent(this, ReminderActivity.class)));

        findViewById(R.id.btnNavVehicles).setOnClickListener(v ->
                startActivity(new Intent(this, VehicleManagementActivity.class)));

        // 4. HEADER BUTTONS (If still in your top layout)
        if (findViewById(R.id.btnSettings) != null) {
            findViewById(R.id.btnSettings).setOnClickListener(v ->
                    startActivity(new Intent(this, SettingsActivity.class)));
        }
    }
}