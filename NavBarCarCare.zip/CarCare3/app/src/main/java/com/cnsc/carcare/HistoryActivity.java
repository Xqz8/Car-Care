package com.cnsc.carcare;

import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import java.util.Locale;

public class HistoryActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;
    LinearLayout layoutHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // --- POSITION 1: Inside onCreate ---
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Add Expense");
        }
        // ------------------------------------

        db = new DatabaseHelper(this);
        session = new SessionManager(this);
        layoutHistory = findViewById(R.id.layoutHistory);

        // Filter spinner
        Spinner spinner = findViewById(R.id.spinnerFilter);
        String[] filters = {"All", "Fuel", "Maintenance", "Repair", "Insurance", "Registration"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, filters);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                String filter = filters[position];
                if (filter.equals("All")) loadHistory(null);
                else loadHistory(filter);
            }
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        loadHistory(null);
    }

    private void loadHistory(String category) {
        layoutHistory.removeAllViews();
        int vehicleId = session.getActiveVehicleId();

        Cursor cursor;
        if (category == null) cursor = db.getExpensesByVehicle(vehicleId);
        else cursor = db.getExpensesByCategory(vehicleId, category);

        if (cursor.getCount() == 0) {
            TextView empty = new TextView(this);
            empty.setText("No expenses found");
            empty.setGravity(Gravity.CENTER);
            empty.setTextColor(getResources().getColor(R.color.gray_medium));
            empty.setPadding(0, 40, 0, 0);
            layoutHistory.addView(empty);
            return;
        }

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String cat = cursor.getString(2);
            double amount = cursor.getDouble(3);
            String date = cursor.getString(4);
            int odo = cursor.getInt(5);
            String notes = cursor.getString(6);

            CardView card = new CardView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 0, 12);
            card.setLayoutParams(params);
            card.setRadius(28f);
            card.setCardElevation(4f);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(28, 20, 28, 20);
            row.setGravity(Gravity.CENTER_VERTICAL);

            // Left: emoji + category
            LinearLayout left = new LinearLayout(this);
            left.setOrientation(LinearLayout.VERTICAL);
            left.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvCat = new TextView(this);
            String emoji = getCategoryEmoji(cat);
            tvCat.setText(emoji + " " + cat);
            tvCat.setTextSize(16f);
            tvCat.setTextColor(getResources().getColor(R.color.blue_dark));
            tvCat.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView tvDate = new TextView(this);
            tvDate.setText(date + (odo > 0 ? " • " + odo + " km" : ""));
            tvDate.setTextColor(getResources().getColor(R.color.gray_medium));
            tvDate.setTextSize(12f);

            left.addView(tvCat);
            left.addView(tvDate);
            if (!notes.isEmpty()) {
                TextView tvNotes = new TextView(this);
                tvNotes.setText(notes);
                tvNotes.setTextColor(getResources().getColor(R.color.gray_dark));
                tvNotes.setTextSize(12f);
                left.addView(tvNotes);
            }

            // Right: amount + delete
            LinearLayout right = new LinearLayout(this);
            right.setOrientation(LinearLayout.VERTICAL);
            right.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);

            TextView tvAmount = new TextView(this);
            tvAmount.setText(String.format(Locale.getDefault(), "₱%.2f", amount));
            tvAmount.setTextSize(16f);
            tvAmount.setTextColor(getResources().getColor(R.color.blue_primary));
            tvAmount.setTypeface(null, android.graphics.Typeface.BOLD);

            Button btnDel = new Button(this);
            btnDel.setText("🗑");
            btnDel.setBackground(null);
            btnDel.setTextSize(18f);
            btnDel.setOnClickListener(v -> {
                db.deleteExpense(id);
                loadHistory(category);
            });

            right.addView(tvAmount);
            right.addView(btnDel);

            row.addView(left);
            row.addView(right);
            card.addView(row);
            layoutHistory.addView(card);
        }
        cursor.close();
    }

    private String getCategoryEmoji(String category) {
        switch (category) {
            case "Fuel": return "⛽";
            case "Maintenance": return "🔧";
            case "Repair": return "🛠️";
            case "Insurance": return "🛡️";
            case "Registration": return "📋";
            case "Car Wash": return "🚿";
            default: return "💰";
        }
    }
}