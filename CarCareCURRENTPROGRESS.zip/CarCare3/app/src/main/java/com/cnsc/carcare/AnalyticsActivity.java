package com.cnsc.carcare;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AnalyticsActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private PieChart pieChart;
    private BarChart barChart;
    private TextView tvAnalyticTotal, tvAnalyticFuel;
    private int vehicleId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analytics);

        // Get the REAL active vehicle ID from your session
        SessionManager session = new SessionManager(this);
        vehicleId = session.getActiveVehicleId();

        db = new DatabaseHelper(this);

        // Bind Views
        tvAnalyticTotal = findViewById(R.id.tvAnalyticTotal);
        tvAnalyticFuel = findViewById(R.id.tvAnalyticFuel);
        pieChart = findViewById(R.id.pieChart);
        barChart = findViewById(R.id.barChart);

        // Load data to the UI
        loadSummaryCards();
        setupPieChart();
        setupBarChart();
    }

    private void loadSummaryCards() {
        // 1. Total Expenses
        double totalSpent = db.getTotalExpensesByVehicle(vehicleId);
        tvAnalyticTotal.setText("₱" + String.format("%.2f", totalSpent));

        // 2. Average Fuel Efficiency
        double avgEff = db.getAverageFuelEfficiency(vehicleId);
        tvAnalyticFuel.setText(String.format("%.1f", avgEff) + " km/L");
    }

    private void setupPieChart() {
        ArrayList<PieEntry> entries = new ArrayList<>();
        HashMap<String, Float> categoryMap = new HashMap<>();

        // Read all expenses and aggregate by category
        Cursor cursor = db.getExpensesByVehicle(vehicleId);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String category = cursor.getString(2); // Category column
                float amount = cursor.getFloat(3);     // Amount column

                if (categoryMap.containsKey(category)) {
                    categoryMap.put(category, categoryMap.get(category) + amount);
                } else {
                    categoryMap.put(category, amount);
                }
            }
            cursor.close();
        }

        for (Map.Entry<String, Float> entry : categoryMap.entrySet()) {
            entries.add(new PieEntry(entry.getValue(), entry.getKey()));
        }

        PieDataSet dataSet = new PieDataSet(entries, "Expense Breakdown");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(12f);

        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PercentFormatter(pieChart));

        pieChart.setData(data);
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setCenterText("Categories");
        pieChart.setCenterTextSize(14f);
        pieChart.animateY(1000);
        pieChart.invalidate(); // Refresh chart
    }

    private void setupBarChart() {
        ArrayList<BarEntry> entries = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();

        // We'll show the last 4 static months for demo.
        // In full app, replace with automated dynamic string sorting.
        String[] months = {"2026-01", "2026-02", "2026-03", "2026-04"};
        String[] monthNames = {"Jan", "Feb", "Mar", "Apr"};

        for (int i = 0; i < months.length; i++) {
            float monthlyTotal = (float) db.getMonthlyExpenses(vehicleId, months[i]);
            entries.add(new BarEntry(i, monthlyTotal));
            labels.add(monthNames[i]);
        }

        BarDataSet dataSet = new BarDataSet(entries, "Monthly Spending");
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        dataSet.setValueTextSize(11f);

        BarData data = new BarData(dataSet);
        data.setBarWidth(0.5f);

        barChart.setData(data);
        barChart.getDescription().setEnabled(false);

        // Configure X Axis
        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setDrawGridLines(false);

        barChart.getAxisRight().setEnabled(false); // Hide right Y axis
        barChart.animateY(1000);
        barChart.invalidate(); // Refresh chart
    }
}