package com.cnsc.carcare;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View; // Added
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import java.util.Locale;

// IMPORTANT: These imports must match your actual file names
import com.cnsc.carcare.MainActivity;
import com.cnsc.carcare.ReminderActivity;
import com.cnsc.carcare.VehicleManagementActivity;
import com.cnsc.carcare.AddExpenseActivity;

public class HistoryActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;
    LinearLayout layoutHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 1. THIS LINE ENSURES THE ENTRANCE IS STAGNANT
        overridePendingTransition(0, 0);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // Action Bar Setup
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Expense History");
        }

        db = new DatabaseHelper(this);
        session = new SessionManager(this);
        layoutHistory = findViewById(R.id.layoutHistory);

        // Initialize Navigation Bar
        setupNavigation();

        // Filter spinner setup
        Spinner spinner = findViewById(R.id.spinnerFilter);
        String[] filters = {"All", "Fuel", "Maintenance", "Repair", "Insurance", "Registration"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, filters);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String filter = filters[position];
                if (filter.equals("All")) loadHistory(null);
                else loadHistory(filter);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Initial load
        loadHistory(null);
    }

    private void setupNavigation() {
        // 1. HOME BUTTON
        findViewById(R.id.btnNavHome).setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(intent);
            overridePendingTransition(0, 0);
        });

        // 2. HISTORY BUTTON
        findViewById(R.id.btnNavHistory).setOnClickListener(v -> {
            if (!(this instanceof HistoryActivity)) {
                Intent intent = new Intent(this, HistoryActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                overridePendingTransition(0, 0);
            } else {
                loadHistory(null);
                Toast.makeText(this, "History Refreshed", Toast.LENGTH_SHORT).show();
            }
        });

        // 3. REMINDERS BUTTON
        findViewById(R.id.btnNavReminders).setOnClickListener(v -> {
            // Check if ReminderActivity exists and is imported
            try {
                Intent intent = new Intent(this, ReminderActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                overridePendingTransition(0, 0);
            } catch (Exception e) {
                Toast.makeText(this, "Reminder Screen not ready", Toast.LENGTH_SHORT).show();
            }
        });

        // 4. GARAGE BUTTON
        findViewById(R.id.btnNavVehicles).setOnClickListener(v -> {
            try {
                Intent intent = new Intent(this, VehicleManagementActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                overridePendingTransition(0, 0);
            } catch (Exception e) {
                Toast.makeText(this, "Garage Screen not ready", Toast.LENGTH_SHORT).show();
            }
        });

        // 5. FAB
        findViewById(R.id.btnNavAddExpense).setOnClickListener(v -> {
            Intent intent = new Intent(this, AddExpenseActivity.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
        });
    }

    private void loadHistory(String category) {
        layoutHistory.removeAllViews();
        int vehicleId = session.getActiveVehicleId();

        Cursor cursor;
        if (category == null) cursor = db.getExpensesByVehicle(vehicleId);
        else cursor = db.getExpensesByCategory(vehicleId, category);

        if (cursor == null || cursor.getCount() == 0) {
            TextView empty = new TextView(this);
            empty.setText("No expenses found");
            empty.setGravity(Gravity.CENTER);
            empty.setTextColor(getResources().getColor(R.color.nav_inactive));
            empty.setPadding(0, 60, 0, 0);
            layoutHistory.addView(empty);
            if (cursor != null) cursor.close();
            return;
        }

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String cat = cursor.getString(2);
            double amount = cursor.getDouble(3);
            String date = cursor.getString(4);
            int odo = cursor.getInt(5);

            // UI Generation
            CardView card = new CardView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 12, 0, 12);
            card.setLayoutParams(params);
            card.setRadius(35f); // Smoother corners like your photo
            card.setCardElevation(4f);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(40, 30, 40, 30);
            row.setGravity(Gravity.CENTER_VERTICAL);

            // Left: Info
            LinearLayout left = new LinearLayout(this);
            left.setOrientation(LinearLayout.VERTICAL);
            left.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvCat = new TextView(this);
            tvCat.setText(getCategoryEmoji(cat) + " " + cat);
            tvCat.setTextSize(16f);
            tvCat.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView tvDate = new TextView(this);
            tvDate.setText(date + (odo > 0 ? " • " + odo + " km" : ""));
            tvDate.setTextColor(getResources().getColor(R.color.nav_inactive));

            left.addView(tvCat);
            left.addView(tvDate);

            // Right: Amount/Delete
            LinearLayout right = new LinearLayout(this);
            right.setOrientation(LinearLayout.VERTICAL);
            right.setGravity(Gravity.END);

            TextView tvAmount = new TextView(this);
            tvAmount.setText(String.format(Locale.getDefault(), "₱%.2f", amount));
            tvAmount.setTextSize(16f);
            tvAmount.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView btnDel = new TextView(this);
            btnDel.setText("🗑 Delete");
            btnDel.setTextColor(android.graphics.Color.RED);
            btnDel.setOnClickListener(v -> {
                db.deleteExpense(id);
                loadHistory(category);
            });

            right.addView(tvAmount);
            right.addView(btnDel);

            row.addView(left);
            row.addView(right);
            card.addView(row);
            layoutHistory.addView(card);
        }
        cursor.close();
    }

    private String getCategoryEmoji(String category) {
        switch (category != null ? category : "") {
            case "Fuel": return "⛽";
            case "Maintenance": return "🔧";
            case "Repair": return "🛠️";
            case "Insurance": return "🛡️";
            case "Registration": return "📋";
            default: return "💰";
        }
    }
}