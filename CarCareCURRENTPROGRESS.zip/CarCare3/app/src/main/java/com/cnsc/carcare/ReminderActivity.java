package com.cnsc.carcare;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import java.util.Calendar;

public class ReminderActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;
    LinearLayout layoutReminders;
    EditText etReminderType, etReminderNote, etDueDate, etDueOdometer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        overridePendingTransition(0, 0);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);

        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        layoutReminders = findViewById(R.id.layoutReminders);
        etReminderType = findViewById(R.id.etReminderType);
        etReminderNote = findViewById(R.id.etReminderNote);
        etDueDate = findViewById(R.id.etDueDate);
        etDueOdometer = findViewById(R.id.etDueOdometer);

        // Date Picker
        etDueDate.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, y, m, d) ->
                    etDueDate.setText(y + "-" + (m + 1) + "-" + d),
                    c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        // Add Button Logic
        findViewById(R.id.btnAddReminder).setOnClickListener(v -> {
            String type = etReminderType.getText().toString().trim();
            String odoInput = etDueOdometer.getText().toString().trim();

            if (type.isEmpty()) {
                Toast.makeText(this, "Please enter a reminder type", Toast.LENGTH_SHORT).show();
                return;
            }

            // SAFE PARSING: Prevent the crash
            int odo = 0;
            try {
                if (!odoInput.isEmpty()) {
                    odo = Integer.parseInt(odoInput);
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter a valid number for Odometer", Toast.LENGTH_SHORT).show();
                return; // Stop the code here so it doesn't save bad data
            }

            int vehicleId = session.getActiveVehicleId();
            if (vehicleId == -1) {
                Toast.makeText(this, "Select a vehicle in the Garage first!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save to Database
            boolean success = db.addReminder(
                    vehicleId,
                    type,
                    etReminderNote.getText().toString(),
                    etDueDate.getText().toString(),
                    odo
            );

            if (success) {
                Toast.makeText(this, "Reminder Added!", Toast.LENGTH_SHORT).show();
                // Clear fields
                etReminderType.setText("");
                etReminderNote.setText("");
                etDueDate.setText("");
                etDueOdometer.setText("");
                loadReminders(); // Refresh the list
            }
        });
        setupNavigation();
        loadReminders();
    }

    private void loadReminders() {
        layoutReminders.removeAllViews();
        int vehicleId = session.getActiveVehicleId();

        // DEBUG: Check if we actually have a vehicle selected
        if (vehicleId == -1) {
            TextView tv = new TextView(this);
            tv.setText("Please select a vehicle in the Garage first.");
            tv.setGravity(Gravity.CENTER);
            layoutReminders.addView(tv);
            return;
        }

        Cursor cursor = db.getRemindersByVehicle(vehicleId);

        if (cursor == null || cursor.getCount() == 0) {
            TextView tv = new TextView(this);
            tv.setText("No upcoming reminders found.");
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, 50, 0, 0);
            layoutReminders.addView(tv);
            return;
        }

        while (cursor.moveToNext()) {
            // Use getColumnIndex to be 100% sure you are getting the right data
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String type = cursor.getString(cursor.getColumnIndexOrThrow("type"));
            String note = cursor.getString(cursor.getColumnIndexOrThrow("note"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("due_date"));

            CardView card = new CardView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 0, 30);
            card.setLayoutParams(params);
            card.setRadius(24f);
            card.setCardElevation(6f);

            LinearLayout inner = new LinearLayout(this);
            inner.setPadding(40, 40, 40, 40);
            inner.setOrientation(LinearLayout.VERTICAL);

            TextView title = new TextView(this);
            title.setText("📍 " + type);
            title.setTextSize(18f);
            title.setTextColor(getResources().getColor(R.color.blue_dark));
            title.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView info = new TextView(this);
            info.setText("Due: " + date + "\nNote: " + note);
            info.setPadding(0, 10, 0, 20);

            Button done = new Button(this);
            done.setText("Mark as Done");
            done.setBackgroundResource(R.drawable.rounded_button_blue); // Use your blue drawable
            done.setTextColor(android.graphics.Color.WHITE);
            done.setOnClickListener(v -> {
                db.deleteReminder(id);
                loadReminders();
            });

            inner.addView(title);
            inner.addView(info);
            inner.addView(done);
            card.addView(inner);
            layoutReminders.addView(card);
        }
        cursor.close();
    }

    private void setupNavigation() {
        findViewById(R.id.btnNavHome).setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });
        findViewById(R.id.btnNavHistory).setOnClickListener(v -> {
            startActivity(new Intent(this, HistoryActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });
        findViewById(R.id.btnNavVehicles).setOnClickListener(v -> {
            startActivity(new Intent(this, VehicleManagementActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            overridePendingTransition(0, 0);
        });
    }
}