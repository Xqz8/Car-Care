package com.cnsc.carcare;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class AddVehicleActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vehicle);

        // --- POSITION 1: Inside onCreate ---
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Add Expense");
        }
        // ------------------------------------

        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        EditText etName = findViewById(R.id.etVehicleName);
        Spinner spinnerType = findViewById(R.id.spinnerType);
        EditText etBrand = findViewById(R.id.etBrand);
        EditText etModel = findViewById(R.id.etModel);
        EditText etYear = findViewById(R.id.etYear);
        EditText etPlate = findViewById(R.id.etPlate);
        EditText etOdometer = findViewById(R.id.etOdometer);
        Button btnSave = findViewById(R.id.btnSaveVehicle);

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String type = spinnerType.getSelectedItem().toString();
            String brand = etBrand.getText().toString().trim();
            String model = etModel.getText().toString().trim();
            String year = etYear.getText().toString().trim();
            String plate = etPlate.getText().toString().trim();
            String odoStr = etOdometer.getText().toString().trim();

            if (name.isEmpty() || brand.isEmpty() || model.isEmpty()) {
                Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int odometer = odoStr.isEmpty() ? 0 : Integer.parseInt(odoStr);
            int userId = session.getUserId();

            long vehicleId = db.addVehicle(userId, name, type, brand, model,
                    year, plate, odometer, "");

            if (vehicleId != -1) {
                session.setActiveVehicle((int) vehicleId);
                Toast.makeText(this, "Vehicle saved!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Error saving vehicle", Toast.LENGTH_SHORT).show();
            }
        });
    }
}