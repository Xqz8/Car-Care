package com.cnsc.carcare;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

// --- CHART IMPORTS ---
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
// ---------------------

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;

    // Chart Variables
    private PieChart pieChart;
    private BarChart barChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        // Bind Chart Views
        pieChart = findViewById(R.id.homePieChart);
        barChart = findViewById(R.id.homeBarChart);

        setupButtons();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardData();
    }

    private void loadDashboardData() {
        int vehicleId = session.getActiveVehicleId();

        // Greeting - Ensure tvGreeting exists in your XML
        TextView tvGreeting = findViewById(R.id.tvGreeting);
        if (tvGreeting != null) {
            int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            if (hour < 12) tvGreeting.setText("Good Morning 👋");
            else if (hour < 18) tvGreeting.setText("Good Afternoon 👋");
            else tvGreeting.setText("Good Evening 👋");
        }

        // User name - Ensure tvUserName exists in your XML
        TextView tvUserName = findViewById(R.id.tvUserName);
        if (tvUserName != null) {
            tvUserName.setText(session.getUserName());
        }

        // Vehicle info and Analytics
        if (vehicleId != -1) {
            Cursor v = db.getVehicleById(vehicleId);
            if (v.moveToFirst()) {
                TextView tvVehicleName = findViewById(R.id.tvVehicleName);
                TextView tvVehicleInfo = findViewById(R.id.tvVehicleInfo);
                TextView tvOdometer = findViewById(R.id.tvOdometer);

                if (tvVehicleName != null) tvVehicleName.setText(v.getString(2));
                if (tvVehicleInfo != null) {
                    String info = v.getString(4) + " " + v.getString(5) + " • " + v.getString(6);
                    tvVehicleInfo.setText(info);
                }
                if (tvOdometer != null) tvOdometer.setText("Odometer: " + v.getInt(8) + " km");
            }
            v.close();

            // 1. Total expenses
            TextView tvTotalExpenses = findViewById(R.id.tvTotalExpenses);
            if (tvTotalExpenses != null) {
                double total = db.getTotalExpensesByVehicle(vehicleId);
                tvTotalExpenses.setText(String.format(Locale.getDefault(), "₱%.2f", total));
            }

            // 2. Monthly expenses
            TextView tvMonthlyExpenses = findViewById(R.id.tvMonthlyExpenses);
            if (tvMonthlyExpenses != null) {
                String currentMonth = new SimpleDateFormat("yyyy-MM", Locale.getDefault())
                        .format(Calendar.getInstance().getTime());
                double monthly = db.getMonthlyExpenses(vehicleId, currentMonth);
                tvMonthlyExpenses.setText(String.format(Locale.getDefault(), "₱%.2f", monthly));
            }

            // 3. Fuel efficiency
            TextView tvFuelEfficiency = findViewById(R.id.tvFuelEfficiency);
            if (tvFuelEfficiency != null) {
                double avgEfficiency = db.getAverageFuelEfficiency(vehicleId);
                tvFuelEfficiency.setText(String.format(Locale.getDefault(), "%.1f km/L", avgEfficiency));
            }

            // 4. Reminders count
            TextView tvReminderCount = findViewById(R.id.tvReminderCount);
            if (tvReminderCount != null) {
                Cursor reminders = db.getRemindersByVehicle(vehicleId);
                tvReminderCount.setText(String.valueOf(reminders.getCount()));
                reminders.close();
            }

            // --- LOAD ANALYTICS CHARTS ---
            setupPieChart(vehicleId);
            setupBarChart(vehicleId);
        }
    }

    private void setupPieChart(int vehicleId) {
        if (pieChart == null) return;

        ArrayList<PieEntry> entries = new ArrayList<>();
        HashMap<String, Float> categoryMap = new HashMap<>();

        Cursor cursor = db.getExpensesByVehicle(vehicleId);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String category = cursor.getString(2);
                float amount = cursor.getFloat(3);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    categoryMap.put(category, categoryMap.getOrDefault(category, 0f) + amount);
                }
            }
            cursor.close();
        }

        if (entries.isEmpty() && categoryMap.isEmpty()) {
            pieChart.setNoDataText("No data available");
        }

        for (Map.Entry<String, Float> entry : categoryMap.entrySet()) {
            entries.add(new PieEntry(entry.getValue(), entry.getKey()));
        }

        PieDataSet dataSet = new PieDataSet(entries, "");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(10f);

        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PercentFormatter(pieChart));

        pieChart.setData(data);

        // --- FIX FOR SCROLLING ---
        // Disabling touch lets the NestedScrollView handle the swipe
        pieChart.setTouchEnabled(false);
        pieChart.setRotationEnabled(false);
        // -------------------------

        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.getLegend().setEnabled(false);
        pieChart.setHoleRadius(40f);
        pieChart.setTransparentCircleRadius(45f);
        pieChart.animateY(1000);
        pieChart.invalidate();
    }

    private void setupBarChart(int vehicleId) {
        if (barChart == null) return;

        ArrayList<BarEntry> entries = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();

        for (int i = 3; i >= 0; i--) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MONTH, -i);
            String monthQuery = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(cal.getTime());
            String monthName = new SimpleDateFormat("MMM", Locale.getDefault()).format(cal.getTime());

            float monthlyTotal = (float) db.getMonthlyExpenses(vehicleId, monthQuery);
            entries.add(new BarEntry(3 - i, monthlyTotal));
            labels.add(monthName);
        }

        BarDataSet dataSet = new BarDataSet(entries, "Spending");
        dataSet.setColors(ColorTemplate.LIBERTY_COLORS);

        BarData data = new BarData(dataSet);
        data.setBarWidth(0.6f);

        barChart.setData(data);

        // --- FIX FOR SCROLLING ---
        barChart.setTouchEnabled(false);
        barChart.setPinchZoom(false);
        barChart.setScaleEnabled(false);
        // -------------------------

        barChart.getDescription().setEnabled(false);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);

        barChart.getAxisRight().setEnabled(false);
        barChart.animateY(1000);
        barChart.invalidate();
    }

    private void setupButtons() {
        if (findViewById(R.id.btnNavAddExpense) != null) {
            findViewById(R.id.btnNavAddExpense).setOnClickListener(v ->
                    startActivity(new Intent(this, AddExpenseActivity.class)));
        }

        if (findViewById(R.id.btnNavHome) != null) {
            findViewById(R.id.btnNavHome).setOnClickListener(v -> {
                loadDashboardData();
                Toast.makeText(this, "Dashboard Updated", Toast.LENGTH_SHORT).show();
            });
        }

        if (findViewById(R.id.btnNavHistory) != null) {
            findViewById(R.id.btnNavHistory).setOnClickListener(v ->
                    startActivity(new Intent(this, HistoryActivity.class)));
        }

        if (findViewById(R.id.btnNavReminders) != null) {
            findViewById(R.id.btnNavReminders).setOnClickListener(v ->
                    startActivity(new Intent(this, ReminderActivity.class)));
        }

        if (findViewById(R.id.btnNavVehicles) != null) {
            findViewById(R.id.btnNavVehicles).setOnClickListener(v ->
                    startActivity(new Intent(this, VehicleManagementActivity.class)));
        }

        if (findViewById(R.id.btnSettings) != null) {
            findViewById(R.id.btnSettings).setOnClickListener(v ->
                    startActivity(new Intent(this, SettingsActivity.class)));
        }
    }
}