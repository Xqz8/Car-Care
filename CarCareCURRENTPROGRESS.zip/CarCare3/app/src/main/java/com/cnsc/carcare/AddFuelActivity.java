package com.cnsc.carcare;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.Locale;

public class AddFuelActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;
    EditText etLiters, etTotalCost, etPricePerLiter, etOdometer, etDate;
    TextView tvEfficiency;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_fuel);

        // --- POSITION 1: Inside onCreate ---
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Add Expense");
        }
        // ------------------------------------

        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        etLiters = findViewById(R.id.etLiters);
        etTotalCost = findViewById(R.id.etTotalCost);
        etPricePerLiter = findViewById(R.id.etPricePerLiter);
        etOdometer = findViewById(R.id.etOdometer);
        etDate = findViewById(R.id.etDate);
        tvEfficiency = findViewById(R.id.tvEfficiency);

        // Auto-calculate price per liter
        TextWatcher calcWatcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) { calculatePricePerLiter(); }
        };
        etLiters.addTextChangedListener(calcWatcher);
        etTotalCost.addTextChangedListener(calcWatcher);

        // Today's date
        Calendar cal = Calendar.getInstance();
        etDate.setText(String.format(Locale.getDefault(), "%d-%02d-%02d",
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)));

        etDate.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, day) ->
                    etDate.setText(String.format(Locale.getDefault(), "%d-%02d-%02d", year, month + 1, day)),
                    c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        findViewById(R.id.btnSave).setOnClickListener(v -> saveFuelLog());
    }

    private void calculatePricePerLiter() {
        try {
            double liters = Double.parseDouble(etLiters.getText().toString());
            double cost = Double.parseDouble(etTotalCost.getText().toString());
            if (liters > 0) {
                double price = cost / liters;
                etPricePerLiter.setText(String.format(Locale.getDefault(), "%.2f", price));
            }
        } catch (NumberFormatException ignored) {}
    }

    private void saveFuelLog() {
        String litersStr = etLiters.getText().toString().trim();
        String costStr = etTotalCost.getText().toString().trim();
        String odoStr = etOdometer.getText().toString().trim();
        String date = etDate.getText().toString().trim();

        if (litersStr.isEmpty() || costStr.isEmpty() || odoStr.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double liters = Double.parseDouble(litersStr);
        double cost = Double.parseDouble(costStr);
        double pricePerLiter = liters > 0 ? cost / liters : 0;
        int odometer = Integer.parseInt(odoStr);
        int vehicleId = session.getActiveVehicleId();

        long result = db.addFuelLog(vehicleId, liters, cost, pricePerLiter, odometer, date);

        if (result != -1) {
            // Also log as expense
            db.insertExpense(vehicleId, "Fuel", cost, date, odometer, "Fuel fill-up: " + liters + "L", "");
            db.updateVehicleOdometer(vehicleId, odometer);

            // Calculate efficiency for display
            double avgEff = db.getAverageFuelEfficiency(vehicleId);
            tvEfficiency.setText(String.format(Locale.getDefault(), "%.1f km/L avg", avgEff));

            Toast.makeText(this, "Fuel log saved! ⛽", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Error saving", Toast.LENGTH_SHORT).show();
        }
    }
}