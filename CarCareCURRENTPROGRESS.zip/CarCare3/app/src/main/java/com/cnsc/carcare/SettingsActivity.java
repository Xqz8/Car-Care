package com.cnsc.carcare;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // --- POSITION 1: Inside onCreate ---
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Add Expense");
        }
        // ------------------------------------

        session = new SessionManager(this);

        ((TextView) findViewById(R.id.tvSettingsName)).setText(session.getUserName());
        ((TextView) findViewById(R.id.tvSettingsEmail)).setText(session.getUserEmail());

        findViewById(R.id.btnManageVehicles).setOnClickListener(v ->
                startActivity(new Intent(this, VehicleManagementActivity.class)));

        findViewById(R.id.btnViewHistory).setOnClickListener(v ->
                startActivity(new Intent(this, HistoryActivity.class)));

        findViewById(R.id.btnAnalytics).setOnClickListener(v ->
                startActivity(new Intent(this, AnalyticsActivity.class)));

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            session.logout();
            startActivity(new Intent(this, LoginActivity.class));
            finishAffinity();
        });
    }
}