package com.cnsc.carcare;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.Locale;

public class AddExpenseActivity extends AppCompatActivity {
    DatabaseHelper db;
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        // --- POSITION 1: Inside onCreate ---
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Add Expense");
        }
        // ------------------------------------

        db = new DatabaseHelper(this);
        session = new SessionManager(this);

        Spinner spinnerCategory = findViewById(R.id.spinnerCategory);
        EditText etAmount = findViewById(R.id.etAmount);
        EditText etDate = findViewById(R.id.etDate);
        EditText etOdometer = findViewById(R.id.etOdometer);
        EditText etNotes = findViewById(R.id.etNotes);
        Button btnSave = findViewById(R.id.btnSave);

        // Set today's date by default
        Calendar cal = Calendar.getInstance();
        etDate.setText(String.format(Locale.getDefault(), "%d-%02d-%02d",
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)));

        // Date picker
        etDate.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, day) -> {
                etDate.setText(String.format(Locale.getDefault(), "%d-%02d-%02d", year, month + 1, day));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        btnSave.setOnClickListener(v -> {
            String category = spinnerCategory.getSelectedItem().toString();
            String amountStr = etAmount.getText().toString().trim();
            String date = etDate.getText().toString().trim();
            String odoStr = etOdometer.getText().toString().trim();
            String notes = etNotes.getText().toString().trim();

            if (amountStr.isEmpty()) {
                Toast.makeText(this, "Please enter amount", Toast.LENGTH_SHORT).show();
                return;
            }

            double amount = Double.parseDouble(amountStr);
            int odometer = odoStr.isEmpty() ? 0 : Integer.parseInt(odoStr);
            int vehicleId = session.getActiveVehicleId();

            long result = db.insertExpense(vehicleId, category, amount, date, odometer, notes, "");

            if (result != -1) {
                // Update vehicle odometer if new reading is higher
                if (odometer > 0) db.updateVehicleOdometer(vehicleId, odometer);
                Toast.makeText(this, "Expense saved! ✅", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Error saving expense", Toast.LENGTH_SHORT).show();
            }
        });
    }
}